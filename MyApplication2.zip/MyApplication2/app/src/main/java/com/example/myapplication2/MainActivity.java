package com.example.myapplication2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.net.wifi.WifiManager;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    WifiManager wifiManager;
    Button btnonoff, btnDiscover, btnsend;
    ListView listView;
    TextView read_msg_box, connectionStatus;
    EditText writemsg;

    IntentFilter mIntentFilter;
BroadcastReceiver mReceiver;

  WifiP2pManager mManger;
  WifiP2pManager.Channel mChannel;
    private List<WifiP2pDevice> peers = new ArrayList<WifiP2pDevice>();
    String[] deviceNameArray;
    WifiP2pDevice[] deviceArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intitailwork();
        exqListener();


    }

    private void exqListener() {
        btnonoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (wifiManager.isWifiEnabled()) {
                    wifiManager.setWifiEnabled(false);
                    btnonoff.setText("ON");
                } else {
                    wifiManager.setWifiEnabled(true);
                    btnonoff.setText("OFF");
                }
            }
        });




        btnDiscover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mManger.discoverPeers(mChannel, new WifiP2pManager.ActionListener() {
                    @Override
                    public void onSuccess() {
                        connectionStatus.setText("Discovery started");
                    }

                    @Override
                    public void onFailure(int i) {
                        connectionStatus.setText("Discovery Failure");

                    }
                });
            }
        });

    }


    private void intitailwork() {

        btnonoff = (Button) findViewById(R.id.onOff);
        btnDiscover = (Button) findViewById(R.id.discover);
        btnsend = (Button) findViewById(R.id.sendButton);
        listView = (ListView) findViewById(R.id.peerListView);
        read_msg_box = (TextView) findViewById(R.id.readMsg);
        connectionStatus=(TextView) findViewById(R.id.connectionStatus);
        writemsg=(EditText) findViewById(R.id.writeMsg);
        wifiManager=(WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        mManger=(WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);
        mChannel=mManger.initialize(this,getMainLooper(),null);
        mReceiver=new WiFiDirectBroadCastReceiver(mManger,mChannel,this);

        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);

    }
WifiP2pManager.PeerListListener peerListListener = new WifiP2pManager.PeerListListener() {
    @Override
    public void onPeersAvailable(WifiP2pDeviceList peerList) {
        if(!peerList.getDeviceList().equals(peers))
        {
            peers.clear();
            peers.addAll(peerList.getDeviceList());
            deviceNameArray= new String[peerList.getDeviceList().size()];
            deviceArray=new  WifiP2pDevice[peerList.getDeviceList().size()];
            int index=0;

            for(WifiP2pDevice device:peerList.getDeviceList())
            {
                deviceNameArray[index]=device.deviceName;
                deviceArray[index]=device;
                index++;
            }
            ArrayAdapter<String> adapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,deviceNameArray);
            listView.setAdapter(adapter);

        }
        if (peers.size()==0){
            Toast.makeText(getApplicationContext(),"NO DEvice Found",Toast.LENGTH_SHORT).show();

        }

    }
};





    @Override
    protected void onResume(){
        super.onResume();

        mReceiver = new WiFiDirectBroadCastReceiver(mManger, mChannel, this);
        registerReceiver(mReceiver, mIntentFilter);
    }
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mReceiver);


    }

}





















