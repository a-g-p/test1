package com.example.myapplication2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pManager;
import android.widget.Toast;

public class WiFiDirectBroadCastReceiver extends BroadcastReceiver {




      private WifiP2pManager mManger;
      private WifiP2pManager.Channel mChannel;
  private MainActivity mActivity;
  public WiFiDirectBroadCastReceiver(WifiP2pManager mManger, WifiP2pManager.Channel mChannel,MainActivity mActivity)

  {

  this.mManger= mManger;
  this.mActivity=mActivity;
  this.mChannel=mChannel;

  }


    @Override
    public void onReceive(Context context, Intent intent) {


      String action = intent.getAction();
      if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(action)) {
        int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
        if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
          Toast.makeText(context,"Wifi on",Toast.LENGTH_SHORT).show();
        }
        else {
          Toast.makeText(context,"Wifi off",Toast.LENGTH_SHORT).show();
        }

        } else if (WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION.equals(action)) {

        if (mManger!=null)
        {
          mManger.requestPeers(mChannel,mActivity.peerListListener);
        }
        } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(action)) {

          // Connection state changed! We should probably do something about
          // that.

        } else if (WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION.equals(action)) {


        }
      }


    }

